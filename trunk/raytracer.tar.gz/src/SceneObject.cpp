/*
 * SceneObject.cpp
 *
 *  Created on: 27.10.2011
 *      Author: philipp
 */

//#include "SceneObject.h"

//SceneObject::SceneObject(){

//}

//virtual SceneObject::~SceneObject(){

//}

//virtual CVector<float> collision(Ray ray, bool* collided, CVector<float> color){

//}
